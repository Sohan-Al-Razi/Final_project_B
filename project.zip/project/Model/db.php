<?php
class db{
 
function OpenCon()
 {
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $db = "project";
 $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
 
 return $conn;
 }
 
 function CheckUser($conn,$table,$username,$password)
 {
   $result = $conn->query("SELECT * FROM $table WHERE username='$username' AND password='$password'");
   return $result;
 }

 function CheckUique($conn,$table,$username)
 {
$result = $conn->query("SELECT * FROM  $table WHERE username='$username'");
 return $result;
 }

 function UpdateUser($conn,$table,$name,$username,$email,$phone,$address)
 {
  $result = $conn->query("UPDATE $table SET name='$name',email='$email',phone='$phone',address='$address' WHERE username='$username'");
  return $result;
 }

 function InsertUser($conn,$table,$name,$username,$password,$gender,$email,$phone,$address,$destination)
 {
  $result = $conn->query("INSERT INTO $table (name, username, password, gender, email, phone, address, picture) VALUES ('$name','$username', '$password', '$gender', '$email', '$phone', '$address', '$destination')");
  return $result;
 }

 function DeleteUser($conn,$table,$username)
 {
  $result = $conn->query("DELETE FROM $table WHERE username='$username'");
  return $result;
 }

 function GetUser($conn,$table,$username)
 {
$result = $conn->query("SELECT * FROM  $table WHERE username='$username'");
 return $result;
 }

function CloseCon($conn)
 {
 $conn -> close();
 }
}
?>