<?php 

include('../Model/db.php');
$isvalidate = ""; 
$message = $error = "";
$usernameErr = $passwordErr = ""; 
$uname = $pass = ""; 
 if(isset($_POST["submit"]))  
 {
     
      if(empty($_POST["username"]))  
      {  
          $usernameErr = "Name is required";
         

      }   
     
      if(empty($_POST["password"]))  
      {  
           $passwordErr = "Password is required";
           
      }
     
     if($usernameErr=="" && $passwordErr=="")
     {
          $username=$_POST['username'];
          $password=$_POST['password'];
          $connection = new db();
          $conobj=$connection->OpenCon();
          $userQuery=$connection->CheckUser($conobj,"users",$username,$password);
          if ($userQuery->num_rows > 0)
          {
               session_start();
               $_SESSION["user"] = $username;
               $_SESSION["password"] = $password;
               header("location: ../View/Dashboard.php");
          }
          else
          {
               $error = "Username or Password is incorrect";
          }
          
          $connection->CloseCon($conobj);
     }
}


?>