<?php
include '../Model/db.php';

$updateMessage="";
session_start();
$username = $_SESSION['user'];

if(isset($_POST["submit"]))  
{
			$name = $_POST['name'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];
            $address = $_POST['address'];

            $connection = new db();
            $conobj=$connection->OpenCon();
            $userQuery=$connection->UpdateUser($conobj,"users",$name,$username,$email,$phone,$address);
            if ($userQuery===TRUE) 
            {
               $updateMessage = "User Data Updated";
          }
          else 
          {
               $updateMessage = "User Data not Updated";
          }
            $connection->CloseCon($conobj);

			$stored_users = json_decode(file_get_contents("../Model/users.json"), true);
}

		foreach ($stored_users as $key => $user) {
				if(($username == $user['username']))
                {
                    $stored_users[$key]['name'] = $name;
                    $stored_users[$key]['e-mail'] = $email;
                    $stored_users[$key]['phone'] = $phone;
                    $stored_users[$key]['address'] = $address;
  
				}
                else {
				//echo "Wrong username or password";
			}
        }
       
        if(file_exists('../Model/users.json'))  
        {    
              
             $final_data = json_encode($stored_users, JSON_PRETTY_PRINT);  
             if(file_put_contents('../Model/users.json', $final_data))  
             {  
                  echo $message = "Profile Updated Successfully"; 
                  header("location: ../View/Profile.php");
             }  
        }  
        else  
        {  
             $error = 'JSON File not exits';  
        }  

?>