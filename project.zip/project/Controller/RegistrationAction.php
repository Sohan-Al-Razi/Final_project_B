<?php 
include('../Model/db.php');
$isvalidate = ""; 
$message = $error ="";
$nameErr = $usernameErr = $passwordErr = $cpasswordErr = $genderErr = $emailErr =  $phoneErr = $addressErr = ""; 
$name = $username = $password = $cpassword = $gender = $email =  $phone = $address = ""; 
 if(isset($_POST["submit"]))  
 {
     $isvalidate = true;  
      if(empty($_POST["name"]))  
      {  
          $nameErr = "Name is required";
          $isvalidate = false;
      }    else {
          $name = test_input($_POST["name"]);
     }
      if(empty($_POST["username"]))  
      {  
          $usernameErr = "User Name is required";
          $isvalidate = false;

      }  else {
          $username = test_input($_POST["username"]);
     }
      if(empty($_POST["password"]))  
      {  
           $passwordErr = "Password is required";
           $isvalidate = false;
      } else {
          $password = test_input($_POST["password"]);
     }
      if(empty($_POST["cpassword"]))  
      {  
           $cpasswordErr = "Password is required";
           $isvalidate = false;
      } else {
          $cpassword = test_input($_POST["cpassword"]);
     }
      
      if(empty($_POST["gender"]))  
      {  
           $genderErr = "Gender is required";
           $isvalidate = false;
      } else {
          $gender= test_input($_POST["gender"]);
     }
      if(empty($_POST["email"]))  
      {  
           $emailErr = "Email is required";
           $isvalidate = false;
      }  else {
          $email= test_input($_POST["email"]);
     }
      if(empty($_POST["phone"]))  
      {  
           $phoneErr = "Phone is required";
           $isvalidate = false;
      } else {
          $phone = test_input($_POST["phone"]);
     } 
      if(empty($_POST["address"]))  
      {  
           $addressErr = "Address is required";
           $isvalidate = false;
      } else {
          $address = test_input($_POST["address"]);
     } 
     
     $picName = $_POST["username"];
     $source = $_FILES['picture']['tmp_name'];
    // $dotPosition = strpos($fileName, '.');
     $ext = explode(".", $_FILES['picture']['name']);
     $ext = $ext[count($ext) - 1];
     $destination = '../Resources/ProPic/'. $picName . '.' . $ext;
     move_uploaded_file($source, $destination);

     if($isvalidate)
     {
          $connection = new db();
          $conobj=$connection->OpenCon();
          $userQuery=$connection->InsertUser($conobj,"users",$name,$username,$password,$gender,$email,$phone,$address,$destination);
          if ($userQuery===TRUE) 
          {
               $error = "User Data inserted";
          }
          else 
          {
               $error = "User Data not inserted";
          }
          $connection->CloseCon($conobj);
     }
}

if(!empty($_REQUEST["checkUserName"]))
{
     $connection = new db();
     $conobj=$connection->OpenCon();
     $userQuery=$connection->CheckUique($conobj,"users",$_REQUEST["checkUserName"]);
     
     if ($userQuery->num_rows > 0)
     {
          echo "Username cannot be taken.";
     }
     $connection->CloseCon($conobj);
}

function test_input($data) {
     $data = trim($data);
     $data = stripslashes($data);
     $data = htmlspecialchars($data);
     return $data;
}


if(file_exists('../Model/users.json') && $isvalidate)  
{
     $current_data = file_get_contents('../Model/users.json');  
     $array_data = json_decode($current_data, true);
     $extra = array(
          'name'        =>       $name,
          'username'    =>       $username,
          'password'    =>       $password, 
          'cpassword'   =>       $cpassword, 
          'gender'      =>       $gender, 
          'e-mail'      =>       $email,
          'phone'       =>       $phone,  
          'address'     =>       $address,
          'picture'     =>       $destination,
     );  
     $array_data[] = $extra;  
     $final_data = json_encode($array_data, JSON_PRETTY_PRINT);  
     if(file_put_contents('../Model/users.json', $final_data))  
     {  
          echo $message = "<label class='text-success'>File Appended Success fully</p>";  
     }  
}
else  
{  
     $error = '';  
}  
?>  