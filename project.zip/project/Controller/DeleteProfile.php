<?php 
include '../Model/db.php';
session_start();

			$username = $_SESSION['user'];
			$password = $_POST['password'];
            $newpassword = $_POST['newpassword'];
			$stored_users = json_decode(file_get_contents("../Model/users.json"), true);

		foreach ($stored_users as $key => $user) {
				if(($username == $user['username']))
                {
                    unset($stored_users[$key]);
                    
				}
                else {
				//echo "Wrong username or password";
			}
        }
       
        if(file_exists('../Model/users.json'))  
        {    
              
             $final_data = json_encode($stored_users, JSON_PRETTY_PRINT);  
             if(file_put_contents('../Model/users.json', $final_data))  
             {  
                $connection = new db();
                $conobj=$connection->OpenCon();
                $userQuery=$connection->DeleteUser($conobj,"users",$username);
                $connection->CloseCon($conobj);
                
                header("location: ../View/Logout.php"); exit();
             }  
        }  
        else  
        {  
             $error = 'JSON File not exits';  
        }  

?>