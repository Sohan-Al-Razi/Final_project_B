<?php 
session_start();

			$id = $_POST['id'];
			$stored_manager = json_decode(file_get_contents("../Model/manager.json"), true);

		foreach ($stored_manager as $key => $manager) {
				if(($id == $manager['id']))
                {
                    unset($stored_manager[$key]);
                    
				}
                else {
				//echo "Wrong username or password";
			}
        }
       
        if(file_exists('../Model/manager.json'))  
        {    
              
             $final_data = json_encode($stored_manager, JSON_PRETTY_PRINT);  
             if(file_put_contents('../Model/manager.json', $final_data))  
             {  
                header("location: ../View/ManagerManagement.php"); exit();
             }  
        }  
        else  
        {  
             $error = 'JSON File not exits';  
        }  

?>