<?php 
session_start();

			$id = $_POST['id'];
			$stored_food = json_decode(file_get_contents("../Model/food.json"), true);

		foreach ($stored_food as $key => $food) {
				if(($id == $food['id']))
                {
                    unset($stored_food[$key]);
                    
				}
                else {
				//echo "Wrong username or password";
			}
        }
       
        if(file_exists('../Model/users.json'))  
        {    
              
             $final_data = json_encode($stored_food, JSON_PRETTY_PRINT);  
             if(file_put_contents('../Model/food.json', $final_data))  
             {  
                header("location: ../View/ShowAllFood.php"); exit();
             }  
        }  
        else  
        {  
             $error = 'JSON File not exits';  
        }  

?>