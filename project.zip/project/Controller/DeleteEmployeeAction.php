<?php 
session_start();

			$id = $_POST['id'];
			$stored_employee = json_decode(file_get_contents("../Model/employee.json"), true);

		foreach ($stored_employee as $key => $employee) {
				if(($id == $employee['id']))
                {
                    unset($stored_employee[$key]);
                    
				}
                else {
				//echo "Wrong username or password";
			}
        }
       
        if(file_exists('../Model/employee.json'))  
        {    
              
             $final_data = json_encode($stored_employee, JSON_PRETTY_PRINT);  
             if(file_put_contents('../Model/employee.json', $final_data))  
             {  
                header("location: ../View/EmployeeManagement.php"); exit();
             }  
        }  
        else  
        {  
             $error = 'JSON File not exits';  
        }  

?>