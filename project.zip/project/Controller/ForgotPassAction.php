<?php

            $email = $_POST['email'];
            $newpassword = $_POST['newpassword'];
            $isvalidate = ""; 
            $message = $error = "";
            $emailErr = $newpasswordErr = ""; 
            $email = $newpassword = ""; 
             if(isset($_POST["submit"]))  
             {
                 $isvalidate = true;
                  if(empty($_POST["email"]))  
                  {  
                      $emailErr = "Email is required";
                      $isvalidate = false;
            
                  }   else {
                      $email = test_input($_POST["email"]);
                 }
                  if(empty($_POST["newpassword"]))  
                  {  
                       $newpasswordErr = "Password is required";
                       $isvalidate = false;
                  } else {
                      $newpassword = test_input($_POST["newpassword"]);
                 }
                 }
            
            
            function test_input($data) {
                 $data = trim($data);
                 $data = stripslashes($data);
                 $data = htmlspecialchars($data);
                 return $data;
               }
          
          $stored_users = json_decode(file_get_contents("../Model/users.json"), true);

		foreach ($stored_users as $key => $user) {
				if(($email == $user['e-mail']))
                {
                    $stored_users[$key]['password'] = $newpassword;
                    $stored_users[$key]['cpassword'] = $newpassword;

                    
				}
                else {
				//echo "Wrong username or password";
			}
        }
       
        if(file_exists('../Model/users.json'))  
        {    
              
             $final_data = json_encode($stored_users, JSON_PRETTY_PRINT);  
             if(file_put_contents('../Model/users.json', $final_data))  
             {  
                  
                echo $message = "Password set Successfully";  
                header("location: ../View/Login.php"); exit();
             }  
        }  
        else  
        {  
             $error = 'JSON File not exits';  
        }  

?> 