<?php
if(isset($_POST["submit"]))  
{
		  $name = $_POST['name'];
            $price = $_POST['price'];
            $quantity = $_POST['quantity'];
            $description = $_POST['description'];
		  $stored_food = json_decode(file_get_contents("../Model/order.json"), true);
}

		foreach ($stored_food as $key => $food) {
				if(($name == $food['name']))
                {
                    $stored_food[$key]['price'] = $price;
                    $stored_food[$key]['quantity'] = $quantity;
                    $stored_food[$key]['description'] = $description;
  
				}
                else {
				//echo "Wrong username or password";
			}
        }
       
        if(file_exists('../Model/food.json'))  
        {    
              
             $final_data = json_encode($stored_food, JSON_PRETTY_PRINT);  
             if(file_put_contents('../Model/order.json', $final_data))  
             {  
                  echo $message = "Food Item Updated Successfully"; 
                  header("location: ../View/Order.php");
             }  
        }  
        else  
        {  
             $error = 'JSON File not exits';  
        }  

?>