<?php include '../Layout/profile_header.php' ?>
<div>
<form method="POST" enctype="multipart/form-data" action="../Controller/AddFoodAction.php">
      <center>
      <fieldset style="width:600px; height: 390px;">
      <legend>Add Food</legend>
                
                
      
    <div>
        <label>Name:</label>
        <input type="text" name="name">
    </div>
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <div>
        <label>Id:</label>
        <input type="text" name="id">
    </div>
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <div>
        <label>Price:</label>
        <input type="number" name="price">
    </div>
    
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <div>
        <label>Quantity:</label>
        <input type="number" name="quantity">
    </div>
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <div>
        <label>Description:</label>
        <input type="text" name="description">
    </div>
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <div>
        <label>Image:</label>
        <input name="photo" type="file">
    </div>
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <tr>
        <td><input type="submit" name="submit" value="Submit"> <input type="reset" name="reset" value="Reset"></td>
    </tr>
    </fieldset>
    </center>

</form>
</div>
</div>
</div>
<?php include '../Layout/footer.php' ?>