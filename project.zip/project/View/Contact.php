<!DOCTYPE html>
<html>
<head>
	<title>Contact us</title>
  <?php include_once '../Layout/header.php' ?>
  <link rel="stylesheet" href="../Resources/css/style.css">
 
</head>

<body>
<div>
<p>
        <a class="custom-btn" href="Dashboard.php">Back</a>
</p>
</div>
 <div>
 	   <h3 style="color: green; background-color: beige;" align="center">Contact Us</h3>
 </div>

 <table>
  
  <tr>
    <td>Title</td>
    <td>Details</td>
   
  </tr>
  <tr>
    <td>Name</td>
    <td>Restaurant Management Syatem</td>

  </tr>
  <tr>
    <td>Number</td>
    <td>01773161611</td>

  </tr>
  <tr>
    <td>E-mail</td>
    <td>sohanalrazi01@gmail.com</td>

  </tr>
  <tr>
    <td>Address</td>
    <td>9/41,Mirpur, Dhaka</td>

  </tr>
</table>

  <?php include_once '../Layout/footer.php' ?>

</body>
</html>