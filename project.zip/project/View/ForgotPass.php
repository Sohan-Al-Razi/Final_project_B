<?php include '../Layout/header.php' ?>

<div>
<form method="post" action="../Controller/ForgotPassAction.php"> 

	<br>
	<br>
<center>
	<table>
		<tbody >
			<tr>
				<td style="width: 630px;">
					<div style="padding-left:10px;">
					
						<fieldset style="width:580px; height: 170px;">
							
							<legend><b>FORGOT PASSWORD</b></legend>
							<div style="padding:5px;">
								<span style="padding-right:40px;color:green">Email Address</span>: <input type="email" name="email" value="<?php if(isset($_COOKIE["email"])) { echo $_COOKIE["email"]; } ?>">
								<span class="error"> * <?php echo $emailErr;?></span>
							</div>
							
							<div style="padding:5px;">
								<span style="padding-right:58px;color:green;">New Password</span>: <input type="password" name="newpassword" value="<?php if(isset($_COOKIE["newpassword"])) { echo $_COOKIE["newpassword"]; } ?>">
								<span class="error">* <?php echo $newpasswordErr;?></span>
							</div>
							
							
							<hr>
							<center>
							<div style="padding:5px;">
								<input type="submit" name="submit" value="Submit"> 
								
								
							</div>
							</center>
						</fieldset>

					</div>
					
				</td>
			</tr>
		</tbody>
	</table>
	</center>
</div>

<?php include '../Layout/footer.php' ?>