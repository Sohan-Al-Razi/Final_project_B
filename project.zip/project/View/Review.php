<?php

include '../Layout/profile_header.php';
$json = file_get_contents('../Model/review.json');
$array = json_decode($json);
?>
<style>
table, th, td {
  border: 0.5px solid black;
}
</style>

<div>
    <p>
        <a href="Dashboard.php">Back</a>
    </p>
    <center>
    <table>
        <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Description</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($array as $review): ?>
            <tr>
                <td> <?= $review->name; ?> </td>
                <td> <?= $review->email; ?> </td>
                <td> <?= $review->description; ?> </td>
            </tr>
        <?php endforeach;; ?>
        </tbody>
    </table>
                    </center>
</div>

<?php include '../Layout/footer.php' ?>



