<?php include '../Layout/header.php' ; ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>About</title>
</head>

<body>
<p>
        <a class="custom-btn" href="Dashboard.php">Back</a>
    </p>
	<div>
		<center>
		<h1 class="display-3">About Us </h1>
		</center>
	</div>
	<center>
<p class="lead">Custome satisfaction is our first priority.Just ask our regular customers. We combine our own family recipes with style and personal flair to create a unique experience every time you visit us. We strive to make each visit satisfying and memorable.
</p>
</center>
<br>
	<div>
		<center>
			<h1 class="display-2">Thank you! Stay Connected with Us.</h1>
		</center>
	</div>
</center>
 <?php include '../Layout/footer.php' ; ?>
</body>
</html>