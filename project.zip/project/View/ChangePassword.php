<?php include '../Layout/profile_header.php' ?>
<p>
        <a class="custom-btn" href="Dashboard.php">Back</a>
 </p>
<div>
<form method="post" action="../Controller/ChangePassAction.php"> 
<center>
	<table>
		<tbody >
			<tr>
				<td style="width: 630px;">
					<div style="padding-left:10px;">
					
						<fieldset style="width:580px; height: 170px;">
							
							<legend><b>CHANGE PASSWORD</b></legend>
							<div style="padding:5px;">
								<span style="padding-right:40px;">Current Password</span>: <input type="password" name="password" value="">
								<span class="error"></span>
							</div>
							
							<div style="padding:5px;">
								<span style="padding-right:58px;color:green;">New Password</span>: <input type="password" name="newpassword" value="">
								<span class="error"></span>
							</div>
							
							
							<hr>
							<center>
							<div style="padding:5px;">
								<input type="submit" name="submit" value="Submit"> 
								
								
							</div>
							</center>
						</fieldset>

					</div>
					
				</td>
			</tr>
		</tbody>
	</table>
	</center>
</div>

<?php include '../Layout/footer.php' ?>