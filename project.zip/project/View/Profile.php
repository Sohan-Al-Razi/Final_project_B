<?php
include '../Layout/profile_header.php';
include '../Model/db.php';

// $stored_users = json_decode(file_get_contents("../Model/users.json"), true);

// 		foreach ($stored_users as $user) {
// 				if(($_SESSION['user'] == $user['username']))
//                 {
//                     break;
//                     //echo "HI";
// 				}
//                 else {
// 				//echo "Wrong username or password";
// 			}
//         }

$usernameOfUser=$_SESSION['user'];
$user="";
$connection = new db();
$conobj=$connection->OpenCon();
$userQuery=$connection->GetUser($conobj,"users",$usernameOfUser);
while($row = mysqli_fetch_assoc($userQuery)) 
{
    $user= $row;
}
$connection->CloseCon($conobj);

?>
<p>
        <a class="custom-btn" href="Dashboard.php">Back</a>
</p>
<div>
    <div>
        <div>
            <h3>View User: <b><?php echo $_SESSION['user']; ?></b></h3>
        </div>

<center>

<div>
	<table>
		<tbody >
			<tr>
				<td style="width: 630px;">
					<div style="padding-left:10px;">
						<fieldset style="width:580px; height: 215px;">
							
							<legend><b>PROFILE</b></legend>
							
                            <table>
            <tbody>
            <tr>
                <th>Name:</th>
                <td><?php echo $user['name'] ?></td>
            </tr>
            <tr>
                <th>Username:</th>
                <td><?php echo $user['username'] ?></td>
            </tr>
            <tr>
                <th>Gender:</th>
                <td><?php echo $user['gender'] ?></td>
            </tr>
            <tr>
                <th>Email:</th>
                <td><?php echo $user['email'] ?></td>
            </tr>
            <tr>
                <th>Phone:</th>
                <td><?php echo $user['phone'] ?></td>
            </tr>
            <tr>
                <th>Address:</th>
                <td><?php echo $user['address'] ?></td>
            </tr>
           
            </tbody>
        </table>	
        <table  align="right" style="margin: -110px auto;">

        <tr>
        <td> <img style="width: 80px" src="<?php echo $user['picture'] ?>" alt=""></td>
            </tr>
            </table>

            <br>
                            <hr>
							<div style="padding:5px;">
                            <a href="EditProfile.php">Edit Profile</a>
							
                            
                            <a href="../Controller/DeleteProfile.php">Delete Profile</a>
							</div>
						</fieldset>
					</div>
				</td>
			</tr>
		</tbody>
	</table>
</div>


</center>


<?php include '../Layout/footer.php' ?>
