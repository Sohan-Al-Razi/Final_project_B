<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <title>Restaurant Management System</title>
        <link rel="stylesheet" type="text/css" href="http://localhost/project/Resources/css/style.css">

   <?php include_once '../Layout/profile_header.php' ?>

</head>

<body>
   <h1 align="left">Dashboard</h1>
   <!--nav sec strt here--> 
   <div class="nav">
      <div class="wraper">
         <div class="menulist">
            <ul>
               <li><a href="#">Home</a></li>
               <li><a href="./ShowAllFood.php">Show All Food</a></li>
               <li><a href="./BillInfo.php">Customer Information</a></li>
               <li><a href="./Order.php">Order Information</a></li>
               
            
               <li><a href="./About.php">About</a></li>
               <li><a href="./Review.php">Customer Review</a></li>
               <li><a href="./Contact.php">Contact us</a></li>
            </ul>
         </div>
      </div>
   </div>
   <!--nav sec end here--> 


   <?php include_once '../Layout/footer.php' ?>
   


</body>
</html>