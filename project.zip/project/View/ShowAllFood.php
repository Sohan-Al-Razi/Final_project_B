       
<?php

include '../Layout/profile_header.php';
$json = file_get_contents('../Model/food.json');
$array = json_decode($json);
?>
<body>

<div>
    <p>
        <a class="custom-btn" href="Dashboard.php">Back</a>
    </p>
    <center>
    <table>
        <thead>
        <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Id</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Description</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($array as $food): ?>
            <tr>
                <td> <img style="width: 100px" src="<?php echo "$food->picture" ?>" alt="">
                <td> <?= $food->name; ?> </td>
                <td> <?= $food->id; ?> </td>
                <td> <?= $food->price; ?> </td>
                <td> <?= $food->quantity; ?> </td>
                <td> <?= $food->description; ?> </td>
                <td>
                       <form method="POST" action="./UpdateFood.php">
                        <input type="hidden" name="id" value="<?= $food->id; ?>">
                        <button>Order</button>
                    </form>
                    <form method="POST" action="../Controller/DeleteFoodAction.php">
                        <input type="hidden" name="id" value="<?= $food->id; ?>">
                        <button>Dislike</button>
                    </form>
                </td>
            </tr>
        <?php endforeach;; ?>
       
    </table>
                    </center>
</div>

   <?php include_once '../Layout/footer.php' ?>

 </tbody>
 </html>
