<?php include '../Layout/header.php' ?>
<?php include_once '../Controller/LoginAction.php' ?>

<!DOCTYPE html>
<html>
<head>
<script src="../JS/myjs.js"></script>
</head>
<div class="single">
<style>
.error {color: #FF0000;}
</style>
        <form method="post" action="" onsubmit="return validateLoginForm()">  

        <br><br>
        <br><br>
        <br><br>
            
            
            <fieldset align="left" style="width:320px;height: 170px;">
                
                <legend><b>LOGIN</b></legend>
                <p id="error"></p>
                <div style="padding:5px;">
                    User Name: <input type="text" id="username" name="username" value="<?php if(isset($_COOKIE["username"])) { echo $_COOKIE["username"]; } ?>">
                    <span class="error">* <?php echo $usernameErr;?></span>
                </div>
                
                <div style="padding:5px;">
                    Password  :&nbsp;&nbsp; <input type="password" id="password" name="password" value="<?php if(isset($_COOKIE["password"])) { echo $_COOKIE["password"]; } ?>">
                    <span class="error">* <?php echo $passwordErr;?></span>
                </div>
                <?php echo $error; ?>
                <hr>
                
                <input type="checkbox" name="remember" value="1">Remember Me
                
                <div style="padding:5px;">
                    <input type="submit" name="submit" value="Submit">
                    <td> <a href="Registration.php">I Don't have any Account</a></td><br>
                    <center>
                    <td> <a href="ForgotPass.php">Forgot Password</a></td>
</center>
                    
                </div>
            </fieldset>
            
        </form>
        
    </div>
</html>
<?php include '../Layout/footer.php' ?>