<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="../Resources/css/style.css">
</head>
<body>
<p>
        <a class="custom-btn" href="Dashboard.php">Back</a>
</p>
<h1>Thank you for visting</h1>

<?php
echo "Order Comfirmed!";
?>

</body>
</html>