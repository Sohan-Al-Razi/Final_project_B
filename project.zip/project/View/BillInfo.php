       
<?php

include '../Layout/profile_header.php';
$json = file_get_contents('../Model/customer.json');
$array = json_decode($json);
?>
<style>
table, th, td {
  border: 0.5px solid black;
}
</style>

<div>
    <p>
        <a class="custom-btn" href="Dashboard.php">Back</a>
    </p>
    <center>
    <table>
        <thead>
        <tr>
            <th>Name</th>
            <th>Item</th>
            <th>Price</th>
            <th>Quantity</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($array as $customer): ?>
            <tr>
                <td> <?= $customer->name; ?> </td>
                <td> <?= $customer->item; ?> </td>
                <td> <?= $customer->price; ?> </td>
                <td> <?= $customer->quantity; ?> </td>
            </tr>
        <?php endforeach;; ?>
        </tbody>
    </table>
                    </center>
</div>

<?php include '../Layout/footer.php' ?>



