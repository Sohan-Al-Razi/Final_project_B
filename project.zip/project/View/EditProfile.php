<?php include '../Layout/profile_header.php';
include '../Model/db.php';
$usernameOfUser=$_SESSION['user'];
$user="";
$connection = new db();
$conobj=$connection->OpenCon();
$userQuery=$connection->GetUser($conobj,"users",$usernameOfUser);
while($row = mysqli_fetch_assoc($userQuery)) 
{
    $user= $row;
}
$connection->CloseCon($conobj);
?>

<script src="../JS/myjs.js"></script>
<div>

    <p>
        <a class="custom-btn" href="Dashboard.php">Back</a>
    </p>
            <form method="POST" action="../Controller/EditProfileAction.php" onsubmit="return validateProfileForm()">
                  <center>
                  <fieldset style="width:600px; height: 300px;">
                  <legend>Update User</legend> 
                  <br><br><br>
                  
                  <p id="error"></p>
                <div>
                    <label>Name:</label>
                    <input name="name" id="name" value="<?php echo $user['name']; ?>">
                </div>
                <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                <div>
                    <label>Email:</label>
                    <input name="email" id="email" value="<?php echo $user['email']; ?>">
                </div>
                <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                <div>
                    <label>Phone:</label>
                    <input name="phone" id="phone" value="<?php echo $user['phone']; ?>">
                </div>
                <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                <div>
                    <label>Address:</label>
                    <input name="address" id="address" value="<?php echo $user['address']; ?>">
                </div>
                <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                <input type="submit" name="submit" value="Submit">
                </fieldset>
                </center>
            </form>
        </div>
    </div>
</div>
<?php include '../Layout/footer.php' ?>