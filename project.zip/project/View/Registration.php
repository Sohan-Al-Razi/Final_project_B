<?php include '../Layout/header.php' ?>
<?php include_once '../Controller/RegistrationAction.php' ?>

<script src="../JS/myjs.js"></script>
<div>
<style>
.error {color: #FF0000;}
</style>
<br>
<br>
<form method="POST" enctype="multipart/form-data" action="" onsubmit="return validateRegistrationForm()">
      <center>
      <fieldset style="width:600px; height: 390px;">
      <legend>REGISTRATION</legend>
      <?php echo $error; ?>
    <p id="error"></p>
    <div>
        <label>Name:</label>
        <input type="text" id="name" name="name">
        <span class="error">* <?php echo $nameErr;?></span>
    </div>
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <div>
        <label>Username:</label>
        <input type="text" id="username" name="username" onkeyup="CheckUsername()">
        <span class="error">* <?php echo $usernameErr;?></span>
        <p id="message"></p>
    </div>
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <div>
        <label>Password:</label>
        <input type="password" id="password" name="password">
        <span class="error">* <?php echo $passwordErr;?></span>
    </div>
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <div>
        <label>Confirm Password:</label>
        <input type="password" name="cpassword">
        <span class="error">* <?php echo $cpasswordErr;?></span>
    </div>
    
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <label for="gender">Gender:  </label>
    <input type="radio" name="gender" id="male" value="male">  
    <label for="gender">Male </label>
    <input type="radio" name="gender" id="female" value="female">
    <label for="gender">Female </label>
    <input type="radio" name="gender" id="other" value="other">
    <label for="gender">Other </label>
    <span class="error">* <?php echo $genderErr;?></span>
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <div>
        <label>Email:</label>
        <input type="email" id="email" name="email">
        <span class="error">* <?php echo $emailErr;?></span>
    </div>
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <div>
        <label>Phone:</label>
        <input type="number" id="phone" name="phone">
        <span class="error">* <?php echo $phoneErr;?></span>
    </div>
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <div>
        <label>Address:</label>
        <input type="text" id="address" name="address">
        <span class="error">* <?php echo $addressErr;?></span>
    </div>
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <div>
        <label>Image:</label>
        <input name="picture" id="picture" type="file">
    </div>
    <tr>
       <td colspan="2"><hr></td> 
    </tr>
    <tr>
        <td><input type="submit" name="submit" value="Submit"> <input type="reset" name="reset" value="Reset"></td>
        <td> <a href="Login.php">I have an already Account</a></td>
    </tr>
    </fieldset>
    </center>

</form>
</div>
</div>
</div>
<?php include '../Layout/footer.php' ?>