<?php include '../Layout/profile_header.php' ?>

<div>


            <form method="POST" action="../Controller/UpdateFoodAction.php">
                  <center>
                  <fieldset style="width:600px; height: 300px;">
                  <legend>Update Food Item</legend> 
                  <br><br><br>
                <div>
                    <label>Name:</label>
                    <input name="name" value="">
                </div>
                <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                <div>
                    <label>Price:</label>
                    <input name="price" value="">
                </div>
                <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                <div>
                    <label>Quantity:</label>
                    <input name="quantity" value="">
                </div>
                <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                <div>
                    <label>Description:</label>
                    <input name="description" value="">
                </div>
                <tr>
                   <td colspan="2"><hr></td> 
                </tr>
                <input type="submit" name="submit" value="Submit">
                </fieldset>
                </center>
            </form>
        </div>
    </div>
</div>
<?php include '../Layout/footer.php' ?>