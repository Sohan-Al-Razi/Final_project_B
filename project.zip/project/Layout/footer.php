<html>	
<body>
<center>
	<br><br>
	<br><br>

		<div class="foot_block">
				
				<footer class="ftr">
					<div class="copy">
					Restaurant Management System 
					</div>
				</footer>
				
			</div>
		</div>
</center>
	</body>
</html>	