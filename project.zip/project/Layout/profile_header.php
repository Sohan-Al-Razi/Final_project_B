<?php
	include_once "headerCheck.php"
?>

<!DOCTYPE html>
<html>
<head>
	<title>Restaurant Management System</title>
	  <link rel="stylesheet" type="text/css" href="http://localhost/project/Resources/css/style.css">
</head>
<body>

		<div style="color:black;"  align="center" >
			<h1>Restaurant Management System</h1>
		</div>
		<fieldset>
			<div class="menubar"> 
				<div>
					<a href="dashboard.php">Home</a>
				<a href="../View/ChangePassword.php">Change Password</a>
				<a href="../View/Profile.php">Profile</a>
				</div>



				<span>Welcome, <?php echo $_SESSION['user']?><a href="../View/Logout.php">|Log-out</a>
				</span>			
			</div>

			
		</fieldset>
	</div>

</body>
</html>
<?php echo "<br>"; ?>