				



				<td align="left" style="width:220px;">
					<div style="padding:10px;border-right: 1.2px solid #000000">
						<div>
							<b>Account</b>
							<hr>
						</div>
						<div>
							<ul>
							  <li><a href="dashboard.php">Dashboard</a></li>
							  <li><a href="profile.php">View Profile</a></li>
							  <li><a href="edit_profile.php">Edit Profile</a></li>
							  <li><a href="change_picture.php">Change Profile Picture</a></li>
							  <li><a href="change_password.php">Change Password</a></li>
							  <li><a href="logout.php">Logout</a></li>
							</ul> 
						</div>
						<div style="padding-top: 20px;"></div>
					</div>


					
				</td>

				