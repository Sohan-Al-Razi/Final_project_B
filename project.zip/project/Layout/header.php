<head>
        <meta charset="utf-8">
		<title>Restaurant Management System</title>
        <link rel="stylesheet" type="text/css" href="http://localhost/project/Resources/css/style.css">
	</head>
	<body>


	<center>
        <h2 class="main-title">Restaurant Management System</h2>

        <div class="menubar">
           <div>
                <a href="http://localhost/project/index.php">Index</a>  |
                <a href="http://localhost/project/View/Login.php">Login</a>  |
                <a href="http://localhost/project/View/Registration.php">Registration</a>  |
                <a href="http://localhost/project/View/dashboard.php">Home</a>
           </div>
        </div>
</head>