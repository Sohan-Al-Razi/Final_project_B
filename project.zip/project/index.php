<?php include './Layout/header.php' ?>
<br><br>
<img src="./Resources/Images/aa.jpg" alt="" width="900" height="500">

<?php include './Layout/footer.php' ?>