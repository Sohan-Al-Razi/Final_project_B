function validateLoginForm() 
{
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;
  console.log("In  func");
  if (username == "") 
  {
    document.getElementById("error").innerHTML="Please enter username";
    return false;
  }
  if ( password== "") {
    document.getElementById("error").innerHTML="Please enter password";
    return false;
  }
}

function validateRegistrationForm() 
{
    var name = document.getElementById("name").value;
    var regName = /^[a-zA-Z]+ [a-zA-Z]+$/
    var username = document.getElementById("username").value;
    var contact= document.getElementById("phone").value;
    var passw=  /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
    var password = document.getElementById("password").value;
    var email=document.getElementById("email").value;
    var x = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var fileInput = document.getElementById("picture");
    var filePath = fileInput.value;
    var allowedExtensions = /(\.jpg|\.png)$/i;
    var address = document.getElementById("address").value;
    var gender = document.getElementsByName("gender");
  
    if (!(regName.test(name))) 
    {
      document.getElementById("error").innerHTML="Please enter valid name";
      return false;
    }
    if (username == "") 
    {
      document.getElementById("error").innerHTML="Please enter username";
      return false;
    }

    if (!(passw.test(password))) 
    {
      document.getElementById("error").innerHTML="Please enter valid password";
      return false;
    }

    if (!(gender[0].checked || gender[1].checked || gender[2].checked)) 
    {
      document.getElementById("error").innerHTML="Please select a gender";
      return false;
    }
  
    if (!(x.test(email)))
    {
      document.getElementById("error").innerHTML="Please enter valid email";
      return false;
    }
   if (!(contact.length==11 || contact.length==14)) 
    {
      document.getElementById("error").innerHTML="Please enter valid phone no";
      return false;
    }

    if (address == "") 
    {
      document.getElementById("error").innerHTML="Please enter address";
      return false;
    }
    
    if (!allowedExtensions.exec(filePath)) 
    {
      document.getElementById("error").innerHTML="Please select a valid file";
      fileInput.value = '';
      return false;
    }
}


function validateProfileForm() 
{
    var name = document.getElementById("name").value;
    var regName = /^[a-zA-Z]+ [a-zA-Z]+$/;
    var contact= document.getElementById("phone").value;
    var email=document.getElementById("email").value;
    var x = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var address = document.getElementById("address").value;
  
    if (!(regName.test(name))) 
    {
      document.getElementById("error").innerHTML="Please enter valid name";
      return false;
    }
  
    if (!(x.test(email)))
    {
      document.getElementById("error").innerHTML="Please enter valid email";
      return false;
    }
   if (!(contact.length==11 || contact.length==14)) 
    {
      document.getElementById("error").innerHTML="Please enter valid phone no";
      return false;
    }

    if (address == "") 
    {
      document.getElementById("error").innerHTML="Please enter address";
      return false;
    }
}


function CheckUsername() 
{
  console.log("in unique func");
  var checkUserName = document.getElementById("username").value;
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() 
  {
    if (this.readyState == 4 && this.status == 200) 
    {
      document.getElementById("message").innerHTML = this.responseText;
    }
  uniqueUserName=document.getElementById("message").value;
  };
  xhttp.open("POST", "/project/Controller/RegistrationAction.php?checkUserName="+checkUserName, true);
  xhttp.send();
}